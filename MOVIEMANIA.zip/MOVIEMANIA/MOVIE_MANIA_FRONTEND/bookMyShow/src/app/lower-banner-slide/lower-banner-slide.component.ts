import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lower-banner-slide',
  templateUrl: './lower-banner-slide.component.html',
  styleUrls: ['./lower-banner-slide.component.scss']
})
export class LowerBannerSlideComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
