import { Component, OnInit, DoCheck } from '@angular/core';
import { CommonserviceService } from '../services/commonservice.service';
import { Router } from "@angular/router";
import { SearchMoviePipe } from '../search-movie/search-movie.pipe'

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [ SearchMoviePipe ]
})
export class HeaderComponent implements OnInit {

  constructor(public commonserviceService: CommonserviceService, private searchMoviePipe: SearchMoviePipe, private router: Router, ) { }

  ngOnInit() {
  }
  updateLocationEvent(selectedLocationText) {
   // this.commonserviceService.updateMovieListByLocation();
  }
  updateLanguageEvent(selectedLanguageText) {
   // this.commonserviceService.updateMovieListByLanguage();
  }
}
